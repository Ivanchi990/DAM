package es.goya;

public class Clase32 
{
	public Clase32()
	{
		
	}
	
	
	public String metodoA()
	{
		return "metodoA";
	}
}
