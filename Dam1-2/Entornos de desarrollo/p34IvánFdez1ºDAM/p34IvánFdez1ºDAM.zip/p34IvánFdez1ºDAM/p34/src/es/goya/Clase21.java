package es.goya;

public class Clase21 
{
	public Clase21()
	{
		
	}
	
	
	public String metodo1()
	{
		return "metodo1";
	}
	
	
	public String metodo2()
	{
		return "metodo2";
	}
}
