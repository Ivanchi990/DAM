package es.goya;

public class Clase11 
{
	public Clase11()
	{
		
	}
	
	
	public String metodo1()
	{
		return "metodo1";
	}
	
	
	public String metodo2()
	{
		return "metodo2";
	}
}
