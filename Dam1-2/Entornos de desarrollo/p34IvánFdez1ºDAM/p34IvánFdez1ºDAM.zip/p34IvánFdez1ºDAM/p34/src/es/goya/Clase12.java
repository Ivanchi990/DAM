package es.goya;

public class Clase12 
{
	public Clase12()
	{
		
	}
	
	
	public String metodoA()
	{
		return "metodoA";
	}
}
