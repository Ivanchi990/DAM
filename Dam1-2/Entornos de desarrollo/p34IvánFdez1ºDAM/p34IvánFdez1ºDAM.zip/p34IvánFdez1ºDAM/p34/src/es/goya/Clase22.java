package es.goya;

public class Clase22 
{
	public Clase22()
	{
		
	}
	
	
	public String metodoA()
	{
		return "metodoA";
	}
}
