package es.goya;

public class Clase31 
{
	public Clase31()
	{
		
	}
	
	
	public String metodo1()
	{
		return "metodo1";
	}
	
	
	public String metodo2()
	{
		return "metodo2";
	}
}
