package javaDocGit;

/**
 * Esta clase crea un Tri�ngulo que recibe una base y una altura
 * 
 * @author Iv�n Fdez P�rez
 * @version 05/03/2022
 *
 */

public class Triangulo 
{
	private double base;
	private double altura;
	/**
	 * Contructor de la clase Tri�ngulo
	 * @param base, altura El radio del Tri�ngulo
	 */
	public Triangulo(double base, double altura)
	{
		
	}
	//Cierre del constructor
	
	/**
	*
	*M�todo que devuelve el �rea del Tri�ngulo
	*@return devuelve el �rea del Tri�ngulo
	*
	**/
	public double area(double base, double altura)
	{
		return (base * altura) / 2;
	}

	/**
	*
	*M�todo que devuelve el per�metro del Tri�ngulo
	*@return devuelve el per�metro del Tri�ngulo
	*
	**/
	public double perimetro(double base, double altura)
	{
		return base + 2(altura);
	}
}
