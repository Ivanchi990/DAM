package javaDocGit;

/**
 * Esta clase crea un c�rculo que recibe un radio
 * 
 * @author Iv�n Fdez P�rez
 * @version 05/03/2022
 *
 */

public class Circulo 
{
	private double radio;
	/**
	 * Contructor de la clase c�rculo
	 * @param radio El radio del c�culo
	 */
	public Circulo(double radio)
	{
		this.radio = radio;
	}
	//Cierre del constructor

	/**
	*
	*Método que devuelve el área del círculo
	*@return área del círculo
	*
	**/
	public double area(double radio)
	{
		return Math.PI * (radio * radio);
	}

	/**
        *
        *Método que devuelve el perímetro del círculo
        *@return peímetro del círculo
        *
        **/
        public double perimetro(double radio)
        {
                return Math.PI * 2 * radio;
        }

}
