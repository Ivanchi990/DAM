package javaDocGit;

/**
 * Esta clase crea un rect�ngulo que recibe dos lados
 * 
 * @author Iv�n Fdez P�rez
 * @version 05/03/2022
 *
 */

public class Rectangulo 
{
	private double lado1;
	private double lado2;
	/**
	 * Contructor de la clase rect�ngulo
	 * @param radio El radio del rect�ngulo
	 */
	public Rectangulo(double lado1, double lado2)
	{
		this.lado1 = lado1;
		this.lado2 = lado2;	
	}
	//Cierre del constructor
	
	/**
	*
	*M�todo que devuelve el �rea del rect�ngulo
	*@return devuelve el �rea del rect�ngulo
	*
	**/
	public double area(double lado1, double lado2)
	{
		return lado1 * lado2;
	}

	/**
	*
	*M�todo que devuelve el per�metro del rect�ngulo
	*@return devuelve el per�metro del rect�ngulo
	*
	**/
	public double perimetro(double lado1, double lado2)
	{
		return (lado1 * lado1) + (lado2 * lado2);
	}
}
