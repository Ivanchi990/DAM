package calculadora;

import static org.junit.Assert.*;
import org.junit.Test;

public class CalculadoraTest 
{
	@Test
	void testSuma() 
	{
		Calculadora calculadora = new Calculadora(7,35);
		double resultado = calculadora.sumar();
		double esperado = 42;
		assertEquals(esperado, resultado);
	}
	@Test
	void testResta() 
	{
		Calculadora calculadora = new Calculadora(35,33);
		double resultado = calculadora.restar();
		double esperado = 2;
		assertEquals(esperado, resultado);
	}
	
	@Test
	void testMultiplicacion() 
	{
		Calculadora calculadora = new Calculadora(8,3);
		double resultado = calculadora.multiplicar();
		double esperado = 24;
		assertEquals(esperado, resultado);
	}
	@Test
	void testDividir() 
	{
		Calculadora calculadora = new Calculadora(220,20);
		double resultado = calculadora.dividir();
		double esperado = 11;
		assertEquals(esperado, resultado);
	}
}
