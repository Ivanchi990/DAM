package aad.cafeteriagoya

import aad.cafeteriagoya.databinding.ActivityMostrarPedidoBinding
import aad.cafeteriagoya.provider.DataProvider
import aad.cafeteriagoya.sqlite.MiBDOpenHelper
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MostrarPedido : AppCompatActivity()
{
    var binding: ActivityMostrarPedidoBinding? = null

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        binding = ActivityMostrarPedidoBinding.inflate(layoutInflater)

        mostrarInfo(intent.getIntExtra("id", 0))

        binding!!.button3.setOnClickListener{
            volverPedidos()
        }

        setContentView(binding!!.root)
    }

    fun mostrarInfo(id: Int)
    {
        var base = MiBDOpenHelper(this, null)

        var pedido = base.obtenerPedido(id)
        pedido.moveToFirst()

        var contenido = dameCon(pedido.getString(1))

        binding?.contenidoPedido?.text = "El pedido contiene:\n $contenido"
    }

    fun volverPedidos()
    {
        intent = Intent(this, PedidosActivity::class.java)

        startActivity(intent)
    }

    fun dameCon(content: String): String
    {
        var content = content.split("-")

        var c = ""

        for(p in DataProvider.listaProductos)
        {
            c = c + p.nombre + p.precio + "(${p.categoria})" + "€\n"
        }

        return c
    }
}