package com.example.concurso3.adapter

data class Player(val nombre:String, val helado:String)