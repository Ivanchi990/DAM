package com.example.dambite.entity

data class Plato(
    val id: String,
    val nombre: String,
    val categoria: String,
    val area: String,
    val urlImagen: String
)