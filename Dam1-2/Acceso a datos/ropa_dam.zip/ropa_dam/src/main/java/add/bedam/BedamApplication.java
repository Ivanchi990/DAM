package add.bedam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BedamApplication {

	public static void main(String[] args) {
		SpringApplication.run(BedamApplication.class, args);
	}

}
