package dao;

import modelos.Producto;

public interface ProductoDAO extends GenericDAO<Producto, Long>
{

}
