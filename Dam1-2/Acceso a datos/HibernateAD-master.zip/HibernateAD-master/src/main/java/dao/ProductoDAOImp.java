package dao;

import modelos.Producto;

public class ProductoDAOImp extends GenericDAOImp<Producto, Long> implements  ProductoDAO
{

}
