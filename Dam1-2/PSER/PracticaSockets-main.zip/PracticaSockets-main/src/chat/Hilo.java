package chat;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;

public class Hilo extends Thread{
	
	public Hilo(InputStream inputStream, OutputStream outputStream) {
		
		
		
	}

}
