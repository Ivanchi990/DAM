package practica1;

public class TestServidor {

	public static void main(String[] args) {
		new TCPFicheroServidor(8023);
	}

}
